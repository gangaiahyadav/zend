<?php
return array (
	'Documentation' => 'Documentation',
	'Zend Framework Reference' => 'Zend Framework Reference',
	'jQuery Documentation' => 'jQuery Documentation',
	'Twitter Bootstrap' => 'Twitter Bootstrap',
	'Sidebar' => 'Sidebar',
	'Link' => 'Link',
	'Language' => 'Language',
	'English (US)' => 'English (US)',
	'French' => 'Français',
);