<?php
return array (
	'Documentation' => 'Documentation',
	'Zend Framework Reference' => 'Zend Framework Référence',
	'jQuery Documentation' => 'jQuery Documentation',
	'Twitter Bootstrap' => 'Twitter Bootstrap',
	'Sidebar' => 'Sidebar',
	'Link' => 'Lien',
	'Language' => 'Langue',
	'English (US)' => 'English (US)',
	'French' => 'Français',
);